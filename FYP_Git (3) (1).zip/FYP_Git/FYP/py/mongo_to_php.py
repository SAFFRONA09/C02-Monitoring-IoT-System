import json
import mysql.connector
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.server_api import ServerApi
from bson import ObjectId
import threading

# Replace the placeholder with your MongoDB Atlas connection string
MONGO_URI = "mongodb+srv://arjun_mongo:4Jlmvp7WtjALhIoH@cluster0.6evnplj.mongodb.net/?tlsAllowInvalidCertificates=true"
DB_NAME = 'monitoring_db'
COLLECTION_NAME = 'sensor_readings'

# Replace with your MySQL database credentials
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = ''
MYSQL_DATABASE = 'fyp'

# Custom JSON Encoder that handles MongoDB ObjectId and datetime objects
class CustomJsonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        return super().default(obj)

# Set the Stable API version when creating a new client
mongo_client = AsyncIOMotorClient(MONGO_URI, server_api=ServerApi('1'))

# Connect to the MongoDB collection
mongo_db = mongo_client[DB_NAME]
collection = mongo_db[COLLECTION_NAME]

# Connect to the MySQL database
mysql_conn = mysql.connector.connect(
    host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD, database=MYSQL_DATABASE
)
mysql_cursor = mysql_conn.cursor()

# Listen to changes in the MongoDB collection and update the MySQL database
async def listen_and_update():
    # Clear the MySQL table
    clear_query = "DELETE FROM data"
    mysql_cursor.execute(clear_query)
    mysql_conn.commit()

    # Send all data from MongoDB to MySQL
    async for document in collection.find({}):
        json_data = json.dumps(document, cls=CustomJsonEncoder)
        data = json.loads(json_data)

        date = data.get('datetime')
        temperature = data.get('temperature')
        humidity = data.get('humidity')
        co2 = data.get('co2')
        # print(temperature)
        # print(humidity)
        # print(co2)
        # print()

        if temperature is not None and humidity is not None and co2 is not None:
            insert_query = "INSERT INTO data (date, temperature, humidity, co2) VALUES (%s, %s, %s, %s)"
            mysql_cursor.execute(insert_query, (date, temperature, humidity, co2))
            mysql_conn.commit()

    # Start change stream
    async with collection.watch() as change_stream:
        async for change in change_stream:
            # Convert the new document to JSON
            json_data = json.dumps(change['fullDocument'], cls=CustomJsonEncoder)
            data = json.loads(json_data)

            date = data.get('datetime')
            temperature = data.get('temperature')
            humidity = data.get('humidity')
            co2 = data.get('co2')

            if temperature is not None and humidity is not None and co2 is not None:
                insert_query = "INSERT INTO data (date, temperature, humidity, co2) VALUES (%s, %s, %s, %s)"
                mysql_cursor.execute(insert_query, (date, temperature, humidity, co2))
                mysql_conn.commit()

# Start threading
def start_threading():
    print("threading")
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(listen_and_update())
    loop.run_forever()


