# sendData.py 
from flask import Blueprint, request, jsonify 
import mysql.connector 
import requests 
import asyncio
from pymongo.server_api import ServerApi
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime
 
 
################################################################################### 
 
host = 'localhost'  # Replace with your database host 
username = 'root'  # Replace with your database username 
password = ''  # Replace with your database password 
database = 'fyp'  # Replace with your database name 

MONGO_URI = "mongodb+srv://arjun_mongo:4Jlmvp7WtjALhIoH@cluster0.6evnplj.mongodb.net/?tlsAllowInvalidCertificates=true"
DB_NAME = 'monitoring_db'
COLLECTION_NAME = 'sensor_readings'
 
connection = mysql.connector.connect(host=host, user=username, password=password, database=database) 
cursor = connection.cursor() 
 
send_data_app = Blueprint('send_data_app', name) 
    

@send_data_app.route('/save_settings', methods=['POST']) 
def save_settings(): 
    if request.method == 'POST': 
        data = request.json 
        # Get the selected alert options 
        alert_telegram = int(data.get('alert-telegram', 0)) 
        alert_email = int(data.get('alert-email', 0)) 
 
        # Get the entered thresholds 
        temperature_threshold = float(data.get('temperature-threshold', 0)) 
        co2_threshold = float(data.get('co2-threshold', 0)) 
 
        # Save the data to the database 
        connection = mysql.connector.connect(host=host, user=username, password=password, database=database) 
        cursor = connection.cursor() 
 
        sql = "INSERT INTO settingsdata (alert_telegram, alert_email, temperature_threshold, co2_threshold) VALUES (%s, %s, %s, %s)" 
        values = (alert_telegram, alert_email, temperature_threshold, co2_threshold) 
 
        try: 
            cursor.execute(sql, values) 
            connection.commit() 
            connection.close() 
            return jsonify({"message": "Settings saved successfully"}), 200 
        except mysql.connector.Error as err: 
            print(f"Database error: {err}") 
            return jsonify({"error": str(err)}), 500 
 
    return jsonify({"error": "Invalid request"}), 400 
 
async def insert_data_to_mongo(data):
    # Set the Stable API version when creating a new client
    client = AsyncIOMotorClient(MONGO_URI, server_api=ServerApi('1'))

    # Connect to the desired database and collection
    db = client[DB_NAME]
    collection = db[COLLECTION_NAME]

    # Find the highest id in the collection
    max_id_record = await collection.find_one(sort=[('id', -1)], projection={'id': 1})
    max_id = int(max_id_record['id']) if max_id_record else 0

    # Convert temperature, humidity, and co2 from strings to integers
    temperature = float(data['temperature'])
    humidity = float(data['humidity'])
    co2 = float(data['CO2'])

    # Add the data to the collection with auto-incremented IDs and current datetime
    data_to_insert = {
        "id": max_id + 1,
        "datetime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "temperature": temperature,
        "humidity": humidity,
        "co2": co2
    }

    # Insert the data into the collection
    await collection.insert_one(data_to_insert)

    # Close the client connection
    client.close()

@send_data_app.route('/insert_data', methods=['POST'])
def insert_data():
    print()
    if request.method == 'POST':
        data = request.form  # Use form data instead of JSON
        temperature = data.get('temperature')
        humidity = data.get('humidity')
        co2 = data.get('CO2')

        if temperature is not None and humidity and co2 is not None:
            # Insert the data into the MongoDB collection
            asyncio.run(insert_data_to_mongo(data))
            # Return the inserted data as a response
           
           
            try: 
                
 
                # Fetch user's alert preferences from the database 
                # Assuming you have a settings table that stores alert_telegram and alert_email values
# cursor.execute("SELECT alert_telegram, alert_email, temperature_threshold, co2_threshold FROM settingsdata ORDER BY id DESC LIMIT 1") 
                # result = cursor.fetchone() 

                connection = mysql.connector.connect(host=host, user=username, password=password, database=database)
                cursor = connection.cursor()
                cursor.execute("SELECT alert_telegram, alert_email, temperature_threshold, co2_threshold FROM settingsdata ORDER BY id DESC LIMIT 1")
                result = cursor.fetchone()
                connection.close()

                alert_telegram = result[0] 
                alert_email = result[1] 
                threshold_temperature = result[2] 
                threshold_co2 = result[3] 
 
                # Trigger the alerts based on user's preferences and the latest thresholds 
                if alert_telegram and not alert_email: 
                    check_threshold_url = "http://localhost:5000/check_threshold" 
                    response = requests.post(check_threshold_url, data={"temperature": temperature, "co2": co2, "threshold_temperature": threshold_temperature, "threshold_co2": threshold_co2}) 
                    if response.status_code == 200: 
                        print("Telegram alert triggered successfully.") 
                    else: 
                        print("Failed to trigger Telegram alert.") 
                elif not alert_telegram and alert_email: 
                    check_threshold_url = "http://localhost:5000/handle_occurrence_counters_and_send_email" 
                    response = requests.post(check_threshold_url, data={"temperature": temperature, "co2": co2, "threshold_temperature": threshold_temperature, "threshold_co2": threshold_co2}) 
                    if response.status_code == 200: 
                        print("Email alert triggered successfully.") 
                    else: 
                        print("Failed to trigger Email alert.") 
                elif alert_telegram and alert_email: 
                    # Both alerts are enabled, trigger both 
                    check_threshold_url = "http://localhost:5000/check_threshold" 
                    response = requests.post(check_threshold_url, data={"temperature": temperature, "co2": co2, "threshold_temperature": threshold_temperature, "threshold_co2": threshold_co2}) 
                    if response.status_code == 200: 
                        print("Telegram alert triggered successfully.") 
                    else: 
                        print("Failed to trigger Telegram alert.") 
 
                    check_threshold_url = "http://localhost:5000/handle_occurrence_counters_and_send_email" 
                    response = requests.post(check_threshold_url, data={"temperature": temperature, "co2": co2, "threshold_temperature": threshold_temperature, "threshold_co2": threshold_co2}) 
                    if response.status_code == 200: 
                        print("Email alert triggered successfully.") 
                    else: 
                        print("Failed to trigger Email alert.") 
 
                # Return the inserted data as a response 
                return jsonify({"message": "New record created successfully"}), 200 
            except mysql.connector.Error as err: 
                print(err) 
                return jsonify({"error": str(err)}), 500 
        else: 
            return jsonify({"error": "Invalid data"}), 400