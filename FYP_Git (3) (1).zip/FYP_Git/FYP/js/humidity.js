// async function fetchData() {
//   try {
//     const response = await fetch('fetch_data.php');
//     if (!response.ok) {
//       throw new Error('Error loading data');
//     }
//     const data = await response.json();
//     return data;
//   } catch (error) {
//     console.error('Error loading data:', error);
//     return [];
//   }
// }

async function fetchData() {
  try {
    const response = await fetch('http://localhost:5000/data');
    if (!response.ok) {
      throw new Error('Error loading data');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error loading data:', error);
    return [];
  }
}

let humidityLineGraph;

async function createhumidityLineGraph() {
  if (humidityLineGraph) {
    humidityLineGraph.destroy();
  }
  const data = await fetchData();

  const labels = data.map(item => item.date);
// const temperatureData = data.map(item => item.temperature);
   const humidityData = data.map(item => item.humidity);
 // const co2Data = data.map(item => item.CO2);

  const ctx = document.getElementById('humidityLinegraph').getContext('2d');
  humidityLineGraph = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        // {
          //   label: 'Temperature',
          //   data: temperatureData,
          //   borderColor: 'rgb(255, 99, 132)',
          //   backgroundColor: 'rgba(255, 99, 132, 0.2)',
          //   tension: 0.4,
          //   fill: true,
          // },
          {
            label: 'Humidity',
            data: humidityData,
            borderColor: 'rgb(173, 216, 230)',
            backgroundColor: 'rgba(173, 216, 230, 0.5)',
            tension: 0.4,
            fill: true,
          },
          // {
          //   label: 'CO2',
          //   data: co2Data,
          //   borderColor: 'rgb(75, 192, 192)',
          //   backgroundColor: 'rgba(75, 192, 192, 0.2)',
          //   tension: 0.4,
          //   fill: true,
          // },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          display: true,
          scaleLabel: {
            display: true,
            labelString: 'Date and Time',
          },
        },
        y: {
          display: true,
          scaleLabel: {
            display: true,
            labelString: 'Value',
          },
        },
      },
    },
  });
}

setInterval(() => {
  createhumidityLineGraph()
}, 5000);

