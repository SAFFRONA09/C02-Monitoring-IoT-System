// main.js
class InteractiveChatbox {
    constructor(a, b, c) {
        this.args = {
            button: a,
            chatbox: b
        }
        this.icons = c;
        this.state = false; 
    }

    display() {
        const { button, chatbox } = this.args;
        
        button.addEventListener('click', () => this.toggleState(chatbox));
    }

    toggleState(chatbox) {
        this.state = !this.state;
        this.showOrHideChatBox(chatbox, this.args.button);
    }

    showOrHideChatBox(chatbox, button) {
        if (this.state) {
            chatbox.classList.add('chatbox--active');
            this.toggleIcon(true, button);
        } else if (!this.state) {
            chatbox.classList.remove('chatbox--active');
            this.toggleIcon(false, button);
        }
    }

    toggleIcon(state, button) {
        const { isClicked, isNotClicked } = this.icons;
        let b = button.children[0].innerHTML;

        if (state) {
            button.children[0].innerHTML = isClicked; 
        } else if (!state) {
            button.children[0].innerHTML = isNotClicked;
        }
    }
}

const apiKey = "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"; // Replace with your actual GPT-3.5 Turbo API key
const apiEndpoint = "https://api.openai.com/v1/chat/completions";

// Function to send a message to the GPT-3.5 Turbo API and get the chatbot's response
async function sendMessageToChatbot(message) {
    try {
        const response = await fetch(apiEndpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "system", content: "You are a farmer who is an expert in taking care of plants" }, { role: "user", content: message }]
            })
        });

        if (!response.ok) {
            throw new Error("Chatbot API call failed");
        }

        const data = await response.json();
        return data.choices[0].message.content;
    } catch (error) {
        console.error(error);
        return "An error occurred while processing your message.";
    }
}

// Function to add a new chat message to the chatbox
function addChatMessage(message, role) {
    const chatboxMessages = document.getElementById("chatboxMessages");
    const messageContainer = document.createElement("div");
    messageContainer.classList.add("message-container");

    const messageItem = document.createElement("div");
    messageItem.textContent = message;
    messageItem.classList.add("messages__item");

    if (role === "visitor") {
        messageItem.classList.add("messages__item--visitor");
    } else if (role === "operator") {
        messageItem.classList.add("messages__item--operator");
    }

    messageContainer.appendChild(messageItem);
    chatboxMessages.prepend(messageContainer); // Add the new message at the top
}




// Function to handle user input and chat with the chatbot
async function handleUserInput() {
    const userInputField = document.getElementById("user-input");
    const userMessage = userInputField.value;
    userInputField.value = ""; // Clear the input field after getting the message

    if (userMessage.trim() !== "") {
        addChatMessage(userMessage, "visitor"); // Display the user's message
        const chatbotResponse = await sendMessageToChatbot(userMessage);
        addChatMessage(chatbotResponse, "operator"); // Display the chatbot's response
    }
}

// Add event listener for "Enter" key press in the input field
const userInputField = document.getElementById("user-input");
userInputField.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        handleUserInput();
    }
});

// Rest of the code from app.js
const chatButton = document.querySelector('.chatbox__button');
const chatContent = document.querySelector('.chatbox__support');
const icons = {
    isClicked: '<img src="../images/icons/chatbox-icon.svg" />',
    isNotClicked: '<img src="../images/icons/chatbox-icon.svg" />'
}
const chatbox = new InteractiveChatbox(chatButton, chatContent, icons);
chatbox.display();
chatbox.toggleIcon(false, chatButton);



const chatButtonWrapper = document.querySelector('.chatbox__button-wrapper');


let offsetX, offsetY;
let isDragging = false;

chatButton.addEventListener('mousedown', startDragging);
document.addEventListener('mouseup', stopDragging);
document.addEventListener('mousemove', dragElement);

function startDragging(e) {
    e.preventDefault();
    isDragging = true;
    offsetX = e.clientX - chatButtonWrapper.getBoundingClientRect().left;
    offsetY = e.clientY - chatButtonWrapper.getBoundingClientRect().top;
}

function stopDragging() {
    isDragging = false;
}

function dragElement(e) {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.clientX - offsetX;
    const y = e.clientY - offsetY;
    chatButtonWrapper.style.left = x + 'px';
    chatButtonWrapper.style.top = y + 'px';
}