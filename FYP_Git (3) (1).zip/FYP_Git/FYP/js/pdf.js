// const downloadBtn = document.querySelector('.report span');
// const printableContent = document.getElementById('printable-content');

// downloadBtn.addEventListener('click', () => {
//     const pdf = new jsPDF();

//     // Options for the PDF document
//     const options = {
//         margin: {
//             top: 10,
//             left: 10,
//             right: 10,
//             bottom: 10
//         }
//     };

//     // Add the content of the printable element to the PDF
//     pdf.fromHTML(printableContent, options, () => {
//         // Save the PDF with a specified file name
//         pdf.save('Analytics_Report.pdf');
//     });
// });

const downloadBtn = document.querySelector('.report span');
const printableContent = document.getElementById('printable-content');

downloadBtn.addEventListener('click', () => {
    const opt = {
        margin: 5,
        filename: 'Analytics_Report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };

    html2pdf()
        .from(printableContent)
        .set(opt)
        .save();
});