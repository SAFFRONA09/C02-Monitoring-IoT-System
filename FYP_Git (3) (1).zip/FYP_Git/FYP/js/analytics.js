let counters_co2 = 0;
let counters_temperature = 0;
let threshold_met_temp = 0;
let threshold_met_co2 = 0;


async function fetchThreshold() {
  try {
    const response = await fetch('http://localhost:5000/threshold');

    if (!response.ok) {
      throw new Error('Error loading data');
    }

    const fetchThreshold = await response.json();
    return fetchThreshold;
  } catch (error) {
    console.error('Error loading data:', error);
    // Return an empty object to handle the error gracefully
    return [];
  }
}

// Declare and define fetchData function
async function fetchData() {
  try {
    const response = await fetch('http://localhost:5000/getAnalytics');

    if (!response.ok) {
      throw new Error('Error loading data');
    }

    const fetchData = await response.json();
    return fetchData;
  } catch (error) {
    console.error('Error loading data:', error);
    // Return an empty object to handle the error gracefully
    return [];
  }
}

// window.addEventListener('DOMContentLoaded', async event => {
//   console.log('DOMContentLoaded event fired'); // Check if the event is firing
// let counters_co2 = 0;
// let counters_temperature = 0;
// let threshold_met_temp = 0;
// let threshold_met_co2 = 0;
// Create an async function to wait for data and then process it
async function processData() {
  // Wait for data to be fetched and retrieved
  const data = await fetchData(); 
  const dataThreshold = await fetchThreshold();

  const temperature = data.temperature;
  const CO2 = data.CO2;
  const co2_threshold = dataThreshold.co2_threshold;
  const temperature_threshold = dataThreshold.temperature_threshold;

  // Log the values of the variables
  console.log('Temperature:', temperature);
  console.log('CO2:', CO2);
  console.log('CO2 Threshold:', co2_threshold);
  console.log('Temperature Threshold:', temperature_threshold);
  console.log();

  // Check co2 level and update thresholds
  if (temperature >= temperature_threshold) {
    counters_temperature++;
    console.log("Counter added", counters_temperature);
    if (counters_temperature == 5) {
      threshold_met_temp++;
      // document.getElementById('threshold_temp').innerText = threshold_met_temp;
    }if (counters_temperature >5) {
      counters_temperature =0;
      if(counters_temperature < 5)
      counters_temperature=0;
    }
  }else{
    counters_temperature =0;
  }
  console.log("Counter added", counters_temperature);

  if (CO2 >= co2_threshold) {
    counters_co2++;

    if (counters_co2 == 5) {
      threshold_met_co2++;
      // document.getElementById('threshold_co2').innerText = threshold_met_co2;
    }if (counters_co2 >5) {
      counters_co2 =0;
      if(counters_co2 < 5)
      counters_co2=0;
    }
    } else {
      counters_co2 = 0;
    }
  
  document.getElementById('threshold_temp').innerText = threshold_met_temp;
  document.getElementById('threshold_co2').innerText = threshold_met_co2;

  // Update the values in the dashboard HTML
  console.log('Temperature:', temperature);
  console.log('CO2:', CO2);
  console.log('CO2 Threshold:', co2_threshold);
  console.log('Temperature Threshold:', temperature_threshold);
  console.log('Counters CO2:', counters_co2);
  console.log('Counters Temperature:', counters_temperature);
  console.log('Threshold MET CO2:', threshold_met_co2);
  console.log('Threshold MET Temperature:', threshold_met_temp);

  }

// Call the processData function to start the data processing
processData();
setInterval(processData, 10000);

// });

// This part is commented out because JavaScript does not have an exact equivalent of Python's sleep functionality.
// In JavaScript, we generally use asynchronous functions, like setTimeout, to achieve similar behavior.
// However, the code for resetting weekly counters is not included here as it depends on the specific use case and environment.

// Uncomment and adapt the sleep functionality based on your specific use case.
// Periodically reset the counters (e.g., every hour)
// setInterval(reset_weekly_counters, 3600000); // 3600000 milliseconds = 1 hour
