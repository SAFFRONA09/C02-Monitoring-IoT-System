<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["Email"];
    $password = $_POST["Password"];
    $gender = $_POST["Gender"];

    // Create a new connection to the MySQL database
    $servername = "localhost"; // Replace with your database host
    $username = "root"; // Replace with your database username
    $password = ""; // Replace with your database password
    $dbname = "sensorsdatabase"; // Replace with your database name

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the SQL statement to insert user data into the database using prepared statements
    $stmt = $conn->prepare("INSERT INTO userdetails (Email, Password, Gender) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $email, $password, $gender);

    // Execute the prepared statement
    if ($stmt->execute()) {
        // Close the prepared statement and the database connection
        $stmt->close();
        $conn->close();
        // Redirect to the dashboard page
        header("Location: ../FYP/html/dashboard.html");
        exit; // Make sure to exit after the redirect
    } else {
        echo "Error: " . $stmt->error;
        // Close the prepared statement and the database connection
        $stmt->close();
        $conn->close();
    }
}

?>
