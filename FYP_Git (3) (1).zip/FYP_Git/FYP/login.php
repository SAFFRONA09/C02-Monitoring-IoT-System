<?php

$servername="localhost";
$username="root";
$password="";
$dbname="sensorsdatabase";
$check=mysqli_connect($servername,$username,$password,$dbname);
if($check) {
    //echo "connection ok"
}
else {
    echo "connection fail";
}
$email =$_POST['Email'];
$password=$_POST['Password'];

$data="SELECT * FROM userdetails WHERE Email='$email' && Password='$password'";
$execute=mysqli_query($check,$data);
$count=mysqli_num_rows($execute);
if($count >= 1) {
    header("Location: ../FYP/html/dashboard.html");
}
else{
    echo "Invalid Email/Password";
}

?>
